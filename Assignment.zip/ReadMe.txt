1- Backend server is run on port 8080 if there is any change in this we need to change in apis.js(frontend-canvasasssignment) also to connect the api

2- by default the extension of file is .txt so whenever you save the file please not add any extension in that

3- To run frontend use npm start if it's not work use SKIP_PREFLIGHT_CHECK=true npm start

4- For backend use node index.js to run



