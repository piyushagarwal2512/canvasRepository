import React, { Component } from 'react'
import CanvasDraw from "react-canvas-draw";
import axios from 'axios'
import {serverDomain} from "../apis"

 class Canvas extends Component {
     constructor(props) {
         super(props)
     
         this.state = {
             savedFiles:[]
         }
         this.canvasRef=React.createRef()
     }

     componentDidMount(){
          this.getFilesArray()
     }

     //erase the complete canvas
     clearCanvas=()=>{
         this.canvasRef.current.clear()
         document.getElementById("fileName").value=""
     }

     //when any saved file selected
     openSavedFile=(event)=>{

        if(event.target.value=="-1")
        {
            this.canvasRef.current.clear()
            document.getElementById("fileName").value = ""
            return
        }
        let url=`${serverDomain}file?fileName=${event.target.value}`
         axios.get(url).then((data)=>{
     
                  this.canvasRef.current.clear()
                  this.canvasRef.current.loadSaveData(data.data.toString(),true)
          }).catch((e)=>alert(e))

        
     }

     //gets list of file name to append in dropdown
     getFilesArray=()=>{
         let url=`${serverDomain}filesArray`
        axios.get(url).then((data)=>{
          //  console.log(data.data)
            this.setState({savedFiles:data.data})

        }).catch(e=>{
            this.setState({savedFiles:[]})
            console.log(e)
        })
     }

     //save the new file
     saveFile=()=>{

        let fileName=document.getElementById("fileName").value;
        if(!fileName)
        {
            alert("filename required");
        }
        else{

           let fileData=this.canvasRef.current.getSaveData();
           let fileExt=new Blob([JSON.stringify(fileData)],{type:"text/plain"});
           const formData = new FormData();
            let url=`${serverDomain}saveFile?fileName=${fileName}.txt`
           formData.append('file',fileExt)
           const config = {
            headers: {
                'content-type': 'multipart/form-data'
               }
             }
            axios.post(url,formData,config).then(()=>{
                alert("file saved");
                return true
             }).then(()=>{
                 document.getElementById("fileName").value=""
                 this.getFilesArray();
            }).catch((e)=>{
                alert("Error Occurred : server error or file already exist")

            })
        }
     }
     
    render() {
        const {canvasRef}=this;
        const {savedFiles}=this.state;
        return (
            <React.Fragment>
            <div>
                 <CanvasDraw ref={canvasRef} canvasWidth={"100%"} brushRadius={2}/>
                 
            </div>
            <div style={{marginTop:"20px"}}>
            <input id="fileName" type="text" />
                  <button onClick={this.saveFile}>Save File</button>
                  <button onClick={this.clearCanvas}>Clear Canvas</button>

                 {savedFiles && savedFiles.length>0 && <div>
                
                 <h3>Saved Files</h3>
                 <select onChange={this.openSavedFile} >

                 <option value={"-1"} ></option>
                      {
                         ( savedFiles && savedFiles.map((ele,index)=><option key ={index} value={ele} >{ele}</option>))
                      }
                  </select>
                 
                  </div>
    }
                </div>
            </React.Fragment>
        )
    }
}

export default Canvas
