import React from 'react';
import logo from './logo.svg';
import './App.css';
import {CanvasComponent} from "./Components/index"

const canvasRef=React.createRef();
function App() {

  return (
    <div className="App">
       <CanvasComponent />
    </div>
  );
}

export default App;
